package io.poc.articles_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticlesMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArticlesMsApplication.class, args);
	}

}
